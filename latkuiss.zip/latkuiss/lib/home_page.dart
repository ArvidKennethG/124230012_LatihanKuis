import 'package:flutter/material.dart';
import 'order_page.dart';
import 'login_page.dart';

class HomePage extends StatelessWidget {
  static const String routeName = '/home';
  final String username;

  const HomePage({super.key, required this.username});

  final List<Map<String, dynamic>> menu = const [
    {
      "name": "Nasi Goreng",
      "price": 15000,
      "image":
          "https://img-global.cpcdn.com/recipes/1d1f8d96ff475fdc/1200x630cq70/photo.jpg",
    },
    {
      "name": "Mie Ayam",
      "price": 12000,
      "image":
          "https://cdn0-production-images-kly.akamaized.net/tCuXBrZxB9uYQmFz1ETsMChL0rA=/1200x675/smart/filters:quality(75)/kly-media-production/medias/3434692/original/072794600_1617792179-Resep_Mie_Ayam_Jamur.jpg",
    },
    {
      "name": "Sate Ayam",
      "price": 20000,
      "image":
          "https://img.okezone.com/content/2021/07/23/298/2444943/resep-sate-ayam-madura-enak-dan-mudah-dibuat-Qq0kF5lV3l.jpg",
    },
    {
      "name": "Bakso",
      "price": 15000,
      "image":
          "https://img-global.cpcdn.com/recipes/9f9b75bc7688f1af/1200x630cq70/photo.jpg",
    },
    {
      "name": "Es Teh",
      "price": 5000,
      "image":
          "https://img.inews.co.id/media/600/files/networks/2022/10/10/1f6314a4-1bc6-472f-9a84-0c06c48bbf62.jpeg",
    },
    {
      "name": "Kopi Hitam",
      "price": 8000,
      "image":
          "https://asset.kompas.com/crops/bEqUk7y1e1pS7FrU3qDb4wvGJjY=/0x0:1000x667/750x500/data/photo/2022/03/28/62417f6c46eb7.jpg",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Halo @$username"),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Navigator.pushReplacementNamed(context, LoginPage.routeName);
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Banner
          Container(
            width: double.infinity,
            height: 150,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: NetworkImage(
                  "https://www.tastingtable.com/img/gallery/italian-foods-you-need-to-try-before-you-die/intro-1642621732.jpg",
                ),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            "Daftar Menu:",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),

          // Grid Menu
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: menu.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.9,
              ),
              itemBuilder: (context, index) {
                final item = menu[index];
                return Card(
                  elevation: 3,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Image.network(
                          item["image"],
                          fit: BoxFit.cover,
                          errorBuilder: (c, e, s) =>
                              const Icon(Icons.fastfood, size: 50),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        item["name"],
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text("Rp ${item["price"]}"),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pushNamed(
                            context,
                            OrderPage.routeName,
                            arguments: item,
                          );
                        },
                        child: const Text("Pesan"),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
